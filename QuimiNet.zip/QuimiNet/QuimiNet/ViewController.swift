//
//  ViewController.swift
//  QuimiNet
//
//  Created by Lizzy Cruz and Abe Gonzalez on 30/03/16.
//  Copyright © 2016 Lizzy Cruz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //funcion para que se puedan regrear las demas vistas a esta
    @IBAction func unwindTabla(sender: UIStoryboardSegue) {
        //algo
        
    }


}

